#include "player.h"

Player::Player(Board* board, int color) : board{board}, color{color} {};
